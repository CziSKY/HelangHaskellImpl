module Main where

import System.Random

main :: IO ()
main = putStrLn "Hello, Haskell!"

musics :: [String]
musics =
  [ "Kill You",
    "Lighters",
    "ZOOD",
    "Love the Way You Lie",
    "The Monster",
    "Numb Encore",
    "Kinds Never Die",
    "I Need a Doctor",
    "Lose Yourself",
    "Mockingbird",
    "Beautiful",
    "Not Afraid",
    "Rap God",
    "Phenomenal",
    "Stan",
    "Space Bound",
    "Stan",
    "Guts Over Fear"
  ]

suffixes :: [String]
suffixes = [".mp3", ".ogg", ".flac"]

test :: ghc-prim-0.6.1:GHC.Types.Any ghc-prim-0.6.1:GHC.Types.Any
test = randomRIO (1,1)